document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('loginForm');
  const welcomePage = document.getElementById('welcomePage');
  const usernameDisplay = document.getElementById('usernameDisplay');
  const errorMsg = document.getElementById('error');
  const logoutBtn = document.getElementById('logoutBtn');

  const storedUser = localStorage.getItem('loggedInUser');

  if (storedUser) {
    showWelcome(storedUser);
  }

  document.getElementById('form').addEventListener('submit', function (e) {
    e.preventDefault();
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;

    if (username === 'admin' && password === '1234') {
      localStorage.setItem('loggedInUser', username);
      showWelcome(username);
    } else {
      errorMsg.classList.remove('hidden');
    }
  });

  logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('loggedInUser');
    loginForm.classList.remove('hidden');
    welcomePage.classList.add('hidden');
  });

  function showWelcome(username) {
    usernameDisplay.textContent = username;
    loginForm.classList.add('hidden');
    welcomePage.classList.remove('hidden');
    errorMsg.classList.add('hidden');
  }
});